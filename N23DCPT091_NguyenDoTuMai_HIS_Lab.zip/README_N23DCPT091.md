# HIS Lab – Nộp bài (Nguyễn Đỗ Tú Mai – N23DCPT091)

## Files
- `his_schema_choray.sql` – tạo database & bảng.
- `his_seed.sql` – nạp dữ liệu mẫu và cập nhật tổng tiền hóa đơn.
- `his_triggers.sql` – trigger tự động cập nhật tổng tiền.
- `his_views.sql` – view báo cáo.
- `his_student_meta_N23DCPT091.sql` – dấu vết MSSV.
- `his_checks.sql` – kiểm tra nhanh.
- `run_all_N23DCPT091.sql` – chạy tất cả.

## Cách dùng nhanh (Workbench)
**Cách 1 – One click:**
File → Open SQL Script… → mở `run_all_N23DCPT091.sql` → Execute.

**Cách 2 – Từng bước:**
1) `his_schema_choray.sql`
2) `his_seed.sql`
3) `his_triggers.sql`
4) `his_views.sql`
5) `his_student_meta_N23DCPT091.sql`
6) `his_checks.sql`

## Kiểm tra
```sql
USE his_choray;
SELECT * FROM LabSubmission ORDER BY saved_at DESC;
SELECT invoice_id, total_amount FROM Invoice;
SELECT patient_id, national_id, full_name FROM Patient WHERE national_id='N23DCPT091';
```

## ERD export
Database → Reverse Engineer… → chọn schema `his_choray` → Finish → Layout → Auto Layout → File → Export → PNG (`ERD_HIS_from_SQL.png`).
