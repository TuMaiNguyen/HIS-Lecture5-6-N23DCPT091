-- run_all_N23DCPT091.sql
SOURCE his_schema_choray.sql;
SOURCE his_seed.sql;
SOURCE his_triggers.sql;
SOURCE his_views.sql;
SOURCE his_student_meta_N23DCPT091.sql;
SOURCE his_checks.sql;
