-- his_checks.sql
USE his_choray;
SELECT ii.invoice_id, SUM(ii.amount) AS calc_total
FROM InvoiceItem ii GROUP BY ii.invoice_id;
SELECT i.invoice_id, i.total_amount, t.calc_total,
       (i.total_amount = t.calc_total) AS is_match
FROM Invoice i
JOIN (
  SELECT invoice_id, SUM(amount) AS calc_total
  FROM InvoiceItem GROUP BY invoice_id
) t ON i.invoice_id = t.invoice_id
ORDER BY i.invoice_id;
SELECT * FROM LabSubmission ORDER BY saved_at DESC;
SELECT patient_id, national_id, full_name FROM Patient WHERE national_id='N23DCPT091';
